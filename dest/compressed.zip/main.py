import FreeSimpleGUI as sg

text1 = sg.Text("Select the Files to compress: ")
input1 = sg.InputText()
choose_button1 = sg.FileBrowse("Choose", key='file')

text2 = sg.Text("Select destination folder: ")
input2 = sg.InputText()
choose_button2 = sg.FolderBrowse("Choose", key='folder')

compress_button = sg.Button("Compress")

window = sg.Window("File Zipper", layout=[[text1,input1,choose_button1],[text2,input2,choose_button2],[compress_button]])
while True:
    event,values = window.read()
    print(event)
    print(values)
    filepath = values['file']
    folder = values['folder']
    print(filepath)
    print(folder)
window.close()